/**
 * Wheel representa una rueda (reel) individual de la máquina
 * tragamonedas. Cada rueda muestra en todo momento un símbolo,
 * identificado por un color, que proviene del catálogo de símbolos
 * de la máquina (SlotMachine). La rueda sólo conoce el índice
 * (currentIndex) del símbolo que le corresponde mostrar; es la
 * máquina quien traduce ese índice a un color concreto.
 *
 * Reutiliza los componentes gráficos del paquete shapes (Circle y
 * Rectangle) para su representación visual: un marco (Rectangle) y
 * el símbolo (Circle) dentro de él.
 *
 * @author  Equipo slotMachine
 * @version 1.0
 */
public class Wheel{

    private static final int SIZE = 50;
    private static final int MARGIN = 10;
    private static final int Y_POSITION = 60;

    private Rectangle frame;
    private Circle symbol;
    private int currentIndex;
    private boolean visible;

    /**
     * Crea una rueda vacía (sin símbolo asignado) en la posición
     * horizontal indicada.
     * @param xPosition posición horizontal inicial de la rueda
     */
    public Wheel(int xPosition){
        currentIndex = -1;
        visible = false;
        frame = new Rectangle();
        frame.changeSize(SIZE + MARGIN, SIZE + MARGIN);
        frame.changeColor("gainsboro");
        symbol = new Circle();
        symbol.changeSize(SIZE);
        symbol.changeColor("white");
        reposition(xPosition);
    }

    /**
     * Reubica la rueda en una nueva posición horizontal. Se usa
     * cuando se agregan o eliminan ruedas y las demás deben
     * desplazarse para mantenerse ordenadas de izquierda a derecha.
     * @param x nueva posición horizontal
     */
    public void reposition(int x){
        frame.moveTo(x, Y_POSITION - MARGIN/2);
        symbol.moveTo(x + MARGIN/2, Y_POSITION);
    }

    /**
     * Actualiza el símbolo visible de la rueda.
     * @param index índice del símbolo dentro del catálogo de la máquina
     * @param color color del símbolo a mostrar (null si no hay símbolos)
     */
    public void showSymbol(int index, String color){
        currentIndex = index;
        symbol.changeColor(color == null ? "white" : color);
    }

    /**
     * @return índice actual (dentro del catálogo) del símbolo visible
     */
    public int getCurrentIndex(){
        return currentIndex;
    }

    public void makeVisible(){
        visible = true;
        frame.makeVisible();
        symbol.makeVisible();
    }

    public void makeInvisible(){
        frame.makeInvisible();
        symbol.makeInvisible();
        visible = false;
    }

    /**
     * Resalta visualmente la rueda (usado cuando la máquina llega
     * a un estado ganador).
     * @param highlighted true para resaltar, false para el estado normal
     */
    public void highlight(boolean highlighted){
        frame.changeColor(highlighted ? "gold" : "gainsboro");
        // vuelvo a poner el color para que el circulo se dibuje encima del marco
        symbol.changeColor(symbol.getColor());
    }
}
