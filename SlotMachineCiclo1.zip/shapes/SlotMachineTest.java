import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Pruebas unitarias para SlotMachine. Se prueban tanto los casos en
 * los que las operaciones deben tener éxito como aquellos en los que
 * deben fallar (ok() == false).
 *
 * Nota: las pruebas se ejecutan con la máquina en modo INVISIBLE para
 * evitar que aparezcan diálogos JOptionPane durante la ejecución
 * automática (el comportamiento del JOptionPane en modo visible debe
 * verificarse manualmente, ya que es una ventana modal).
 *
 * @author  Equipo slotMachine
 * @version 1.0
 */
public class SlotMachineTest{

    private SlotMachine machine;

    @Before
    public void setUp(){
        machine = new SlotMachine();
    }

    @Test
    public void testInitialState(){
        assertEquals(0, machine.wheelCount());
        assertEquals(0, machine.symbols().length);
        assertEquals(0, machine.configuration().length);
        assertFalse(machine.isJackpot());
        assertTrue(machine.ok());
        assertFalse(machine.isVisible());
    }

    @Test
    public void testAddWheelSuccess(){
        machine.addWheel(1);
        assertEquals(1, machine.wheelCount());
        assertTrue(machine.ok());

        machine.addWheel(1);
        machine.addWheel(5); // posición fuera de rango -> se ajusta al máximo
        assertEquals(3, machine.wheelCount());
        assertTrue(machine.ok());
    }

    @Test
    public void testAddWheelLimitsLowPosition(){
        machine.addWheel(-3); // posición < 1 -> se usa 1
        assertEquals(1, machine.wheelCount());
        assertTrue(machine.ok());
    }

    @Test
    public void testDelWheelSuccess(){
        machine.addWheel(1);
        machine.addWheel(2);
        machine.delWheel(1);
        assertEquals(1, machine.wheelCount());
        assertTrue(machine.ok());
    }

    @Test
    public void testDelWheelFailsWhenEmpty(){
        machine.delWheel(1);
        assertFalse(machine.ok());
        assertEquals(0, machine.wheelCount());
    }

    @Test
    public void testAddSymbolSuccessAndOrder(){
        machine.addSymbol(1, "red");
        machine.addSymbol(1, "blue"); // se inserta antes de red
        machine.addSymbol(10, "green"); // fuera de rango -> al final
        assertArrayEquals(new String[]{"blue", "red", "green"}, machine.symbols());
        assertTrue(machine.ok());
    }

    @Test
    public void testAddSymbolFailsWithInvalidColor(){
        machine.addSymbol(1, "notacolor");
        assertFalse(machine.ok());
        assertEquals(0, machine.symbols().length);
    }

    @Test
    public void testAddSymbolAllowsDuplicates(){
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "red");
        assertEquals(2, machine.symbols().length);
        assertEquals(1, machine.distinctSymbols());
    }

    @Test
    public void testDelSymbolSuccess(){
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");
        machine.delSymbol("red");
        assertArrayEquals(new String[]{"blue"}, machine.symbols());
        assertTrue(machine.ok());
    }

    @Test
    public void testDelSymbolFailsWhenNotFound(){
        machine.addSymbol(1, "red");
        machine.delSymbol("purple");
        assertFalse(machine.ok());
        assertEquals(1, machine.symbols().length);
    }

    @Test
    public void testDistinctSymbols(){
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");
        machine.addSymbol(3, "red");
        assertEquals(2, machine.distinctSymbols());
    }

    @Test
    public void testPlaceSymbolSuccess(){
        machine.addWheel(1);
        machine.addWheel(2);
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");

        machine.placeSymbol(1, "blue");
        machine.placeSymbol(2, "red");

        assertArrayEquals(new String[]{"blue", "red"}, machine.configuration());
        assertTrue(machine.ok());
    }

    @Test
    public void testPlaceSymbolFailsWhenSymbolDoesNotExist(){
        machine.addWheel(1);
        machine.addSymbol(1, "red");
        machine.placeSymbol(1, "green");
        assertFalse(machine.ok());
    }

    @Test
    public void testPlaceSymbolFailsWhenNoWheels(){
        machine.addSymbol(1, "red");
        machine.placeSymbol(1, "red");
        assertFalse(machine.ok());
    }

    @Test
    public void testSpinOneWheelSuccess(){
        machine.addWheel(1);
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");

        machine.spin(1);

        assertTrue(machine.ok());
        String result = machine.configuration()[0];
        assertTrue(result.equals("red") || result.equals("blue"));
    }

    @Test
    public void testSpinAllSuccess(){
        machine.addWheel(1);
        machine.addWheel(2);
        machine.addWheel(3);
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");

        machine.spin();

        assertTrue(machine.ok());
        for(String color : machine.configuration()){
            assertNotNull(color);
        }
    }

    @Test
    public void testSpinFailsWithoutWheelsOrSymbols(){
        machine.spin(); // sin ruedas ni símbolos
        assertFalse(machine.ok());

        machine.addWheel(1);
        machine.spin(); // hay rueda pero no hay símbolos
        assertFalse(machine.ok());
    }

    @Test
    public void testIsJackpotTrue(){
        machine.addWheel(1);
        machine.addWheel(2);
        machine.addWheel(3);
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");

        machine.placeSymbol(1, "red");
        machine.placeSymbol(2, "red");
        machine.placeSymbol(3, "red");

        assertTrue(machine.isJackpot());
    }

    @Test
    public void testIsJackpotFalse(){
        machine.addWheel(1);
        machine.addWheel(2);
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");

        machine.placeSymbol(1, "red");
        machine.placeSymbol(2, "blue");

        assertFalse(machine.isJackpot());
    }

    @Test
    public void testIsJackpotFalseWithoutWheels(){
        assertFalse(machine.isJackpot());
    }

    @Test
    public void testVisibilityToggle(){
        assertFalse(machine.isVisible());
        machine.makeVisible();
        assertTrue(machine.isVisible());
        machine.makeInvisible();
        assertFalse(machine.isVisible());
    }

    @Test
    public void testExitBlocksFurtherOperations(){
        machine.addWheel(1);
        machine.exit();

        machine.addWheel(1);
        assertFalse(machine.ok());
        assertEquals(1, machine.wheelCount()); // no cambió

        machine.addSymbol(1, "red");
        assertFalse(machine.ok());

        assertFalse(machine.isVisible());
    }

    @Test
    public void testExitIsIdempotent(){
        machine.exit();
        machine.exit(); // no debe lanzar excepción
        assertFalse(machine.isVisible());
    }
}
