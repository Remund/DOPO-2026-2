import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;

/**
 * SlotMachine simula una máquina tragamonedas. La máquina mantiene
 * un catálogo de símbolos (colores, con posibles repeticiones) y un
 * conjunto de ruedas (Wheel). Cada rueda apunta, mediante un índice,
 * a uno de los símbolos del catálogo, que es el que muestra en un
 * momento dado.
 *
 * Reglas generales de posición: las posiciones se enumeran a partir
 * de 1; si la posición es menor a 1 se usa 1; si es mayor al máximo
 * de elementos posibles se usa el máximo.
 *
 * Usabilidad: cuando el simulador está visible y el usuario ingresa
 * un color o símbolo inválido, se le presenta un selector desplegable
 * (JOptionPane) con las opciones válidas disponibles.
 *
 * @author  Equipo slotMachine
 * @version 1.1
 */
public class SlotMachine{

    private static final int BASE_X = 30;
    private static final int SPACING = 70;
    private static final int BODY_Y = 30;
    private static final int BODY_HEIGHT = 100;

    private ArrayList<String> catalog;
    private ArrayList<Wheel> wheels;
    private Rectangle body;
    private Random random;
    private boolean visible;
    private boolean terminated;
    private boolean ok;

    /**
     * Crea una máquina tragamonedas vacía (sin ruedas ni símbolos),
     * inicialmente invisible.
     */
    public SlotMachine(){
        catalog = new ArrayList<String>();
        wheels = new ArrayList<Wheel>();
        random = new Random();
        visible = false;
        terminated = false;
        ok = true;
        body = new Rectangle();
        body.changeSize(BODY_HEIGHT, SPACING);
        body.changeColor("dimgray");
        body.moveTo(BASE_X - 20, BODY_Y);
    }

    /**
     * Agrega una rueda vacía en la posición indicada.
     * @param pos posición (1..numRuedas+1) donde se inserta la rueda
     */
    public void addWheel(int pos){
        if(blocked()) return;
        int insertPos = limitPosition(pos, 1, wheels.size() + 1);
        Wheel wheel = new Wheel(0);
        wheels.add(insertPos - 1, wheel);
        repositionWheels();
        refreshAllWheels();
        if(visible) wheel.makeVisible();
        reportSuccess();
    }

    /**
     * Elimina la rueda ubicada en la posición indicada.
     * @param pos posición (1..numRuedas) de la rueda a eliminar
     */
    public void delWheel(int pos){
        if(blocked()) return;
        if(wheels.isEmpty()){
            reportError("No hay ruedas para eliminar.");
            return;
        }
        int delPos = limitPosition(pos, 1, wheels.size());
        Wheel wheel = wheels.remove(delPos - 1);
        wheel.makeInvisible();
        repositionWheels();
        updateAppearance();
        reportSuccess();
    }

    /**
     * Agrega un símbolo (color) al catálogo de la máquina. Si el color
     * es inválido y la máquina está visible, se abre un selector
     * desplegable con los colores CSS disponibles.
     * @param pos   posición (1..numSímbolos+1) dentro del catálogo
     * @param color nombre del color (estándar CSS)
     */
    public void addSymbol(int pos, String color){
        if(blocked()) return;
        String target = (color != null) ? color.trim().toLowerCase() : "";

        if(!Canvas.isValidColor(target)){
            target = chooseColor(color);
            if(target == null){
                reportError("El color '" + color + "' no es un color CSS válido.");
                return;
            }
        }

        int insertPos = limitPosition(pos, 1, catalog.size() + 1);
        catalog.add(insertPos - 1, target);
        refreshAllWheels();
        reportSuccess();
    }

    /**
     * Elimina la primera ocurrencia del símbolo indicado del catálogo.
     * @param symbol color del símbolo a eliminar
     */
    public void delSymbol(String symbol){
        if(blocked()) return;
        int idx = (symbol == null) ? -1 : catalog.indexOf(symbol.toLowerCase());
        if(idx == -1){
            reportError("El símbolo '" + symbol + "' no existe en la máquina.");
            return;
        }
        catalog.remove(idx);
        refreshAllWheels();
        reportSuccess();
    }

    /**
     * Ubica manualmente un símbolo del catálogo en una rueda específica.
     * Si el símbolo no existe y la máquina está visible, se abre un
     * selector desplegable con los símbolos actualmente en el catálogo.
     * @param wheel  posición (1..numRuedas) de la rueda
     * @param symbol color del símbolo a ubicar
     */
    public void placeSymbol(int wheel, String symbol){
        if(blocked()) return;
        if(wheels.isEmpty()){
            reportError("No hay ruedas en la máquina.");
            return;
        }

        String target = (symbol != null) ? symbol.trim().toLowerCase() : "";
        int idx = catalog.indexOf(target);

        if(idx == -1){
            target = chooseSymbol(symbol);
            idx = (target == null) ? -1 : catalog.indexOf(target);
            if(idx == -1){
                reportError("El símbolo '" + symbol + "' no existe en el catálogo.");
                return;
            }
        }

        int wheelPos = limitPosition(wheel, 1, wheels.size());
        wheels.get(wheelPos - 1).showSymbol(idx, catalog.get(idx));
        updateAppearance();
        reportSuccess();
    }

    /**
     * Gira (al azar) una única rueda de la máquina.
     * @param wheel posición (1..numRuedas) de la rueda a girar
     */
    public void spin(int wheel){
        if(blocked()) return;
        if(wheels.isEmpty() || catalog.isEmpty()){
            reportError("No es posible girar: faltan ruedas o símbolos.");
            return;
        }
        int wheelPos = limitPosition(wheel, 1, wheels.size());
        int idx = random.nextInt(catalog.size());
        wheels.get(wheelPos - 1).showSymbol(idx, catalog.get(idx));
        updateAppearance();
        reportSuccess();
    }

    /**
     * Gira (al azar) todas las ruedas de la máquina.
     */
    public void spin(){
        if(blocked()) return;
        if(wheels.isEmpty() || catalog.isEmpty()){
            reportError("No es posible girar: faltan ruedas o símbolos.");
            return;
        }
        for(Wheel w : wheels){
            int idx = random.nextInt(catalog.size());
            w.showSymbol(idx, catalog.get(idx));
        }
        updateAppearance();
        reportSuccess();
    }

    /**
     * @return los colores de los símbolos del catálogo, en el orden
     *         en que están definidos, comenzando por la posición 1.
     */
    public String[] symbols(){
        return catalog.toArray(new String[0]);
    }

    /**
     * @return la cantidad de colores distintos definidos en el catálogo
     */
    public int distinctSymbols(){
        return new HashSet<String>(catalog).size();
    }

    /**
     * @return los colores actualmente visibles en todas las ruedas de
     *         la máquina, ordenados de izquierda a derecha
     */
    public String[] configuration(){
        String[] config = new String[wheels.size()];
        for(int i = 0; i < wheels.size(); i++){
            int idx = wheels.get(i).getCurrentIndex();
            config[i] = (idx >= 0 && idx < catalog.size()) ? catalog.get(idx) : null;
        }
        return config;
    }

    /**
     * @return true si la configuración actual es ganadora (todas las
     *         ruedas muestran el mismo símbolo y hay al menos una rueda)
     */
    public boolean isJackpot(){
        String[] config = configuration();
        if(config.length == 0) return false;
        for(String s : config){
            if(s == null || !s.equals(config[0])) return false;
        }
        return true;
    }

    /**
     * Hace visible el simulador en pantalla.
     */
    public void makeVisible(){
        if(terminated) return;
        visible = true;
        body.makeVisible();
        for(Wheel w : wheels) w.makeVisible();
        updateAppearance();
    }

    /**
     * Hace invisible el simulador (sigue funcionando internamente).
     */
    public void makeInvisible(){
        body.makeInvisible();
        for(Wheel w : wheels) w.makeInvisible();
        visible = false;
    }

    /**
     * Termina el simulador: oculta la ventana y bloquea operaciones
     * futuras.
     */
    public void exit(){
        if(terminated) return;
        makeInvisible();
        Canvas.getCanvas().closeCanvas();
        terminated = true;
    }

    /**
     * @return true si la última operación de comando se realizó con éxito
     */
    public boolean ok(){
        return ok;
    }

    /**
     * @return true si el simulador está actualmente visible
     */
    public boolean isVisible(){
        return visible;
    }

    /**
     * @return la cantidad de ruedas que tiene actualmente la máquina
     */
    public int wheelCount(){
        return wheels.size();
    }

    private boolean blocked(){
        if(terminated){
            reportError("El simulador ya ha finalizado.");
            return true;
        }
        return false;
    }

    private int limitPosition(int pos, int min, int max){
        if(pos < min) return min;
        if(pos > max) return max;
        return pos;
    }

    private void repositionWheels(){
        for(int i = 0; i < wheels.size(); i++){
            wheels.get(i).reposition(BASE_X + i * SPACING);
        }
        int width = Math.max(1, wheels.size()) * SPACING + 20;
        body.changeSize(BODY_HEIGHT, width);
        body.moveTo(BASE_X - 20, BODY_Y);
    }

    private void refreshAllWheels(){
        for(Wheel w : wheels){
            if(catalog.isEmpty()){
                w.showSymbol(-1, null);
            } else {
                int idx = w.getCurrentIndex();
                if(idx < 0) idx = 0;
                if(idx >= catalog.size()) idx = catalog.size() - 1;
                w.showSymbol(idx, catalog.get(idx));
            }
        }
        updateAppearance();
    }

    private void updateAppearance(){
        boolean jackpot = isJackpot();
        for(Wheel w : wheels) w.highlight(jackpot);
    }

    /**
     * Abre el selector desplegable (chooser) de colores CSS disponibles.
     * Sólo se activa si la máquina está visible.
     * @param invalidColor color inválido ingresado por el usuario
     * @return el color elegido, o null si canceló o no está visible
     */
    private String chooseColor(String invalidColor){
        if(!visible) return null;
        String[] available = Canvas.getAvailableColors();
        Object selected = JOptionPane.showInputDialog(
            null,
            "El color '" + invalidColor + "' no es válido.\n" +
            "Selecciona uno de los colores CSS disponibles:",
            "Selector de Colores",
            JOptionPane.QUESTION_MESSAGE,
            null,
            available,
            available.length > 0 ? available[0] : null
        );
        return (selected == null) ? null : selected.toString();
    }

    /**
     * Abre el selector desplegable (chooser) con los símbolos que sí
     * existen actualmente en el catálogo. Sólo se activa si la máquina
     * está visible y hay símbolos cargados.
     * @param invalidSymbol símbolo inválido ingresado por el usuario
     * @return el símbolo elegido, o null si canceló
     */
    private String chooseSymbol(String invalidSymbol){
        if(!visible || catalog.isEmpty()) return null;
        String[] existing = catalog.toArray(new String[0]);
        Object selected = JOptionPane.showInputDialog(
            null,
            "El símbolo '" + invalidSymbol + "' no existe en el catálogo.\n" +
            "Selecciona uno de los símbolos disponibles:",
            "Selector de Símbolos",
            JOptionPane.QUESTION_MESSAGE,
            null,
            existing,
            existing[0]
        );
        return (selected == null) ? null : selected.toString();
    }

    private void reportError(String message){
        ok = false;
        if(visible){
            JOptionPane.showMessageDialog(null, message,
                "Slot Machine", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void reportSuccess(){
        ok = true;
    }
}
